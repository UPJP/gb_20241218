import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import Router from './Router'; // Router 컴포넌트 import

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Router /> {/* Router 컴포넌트 렌더링 */}
    </BrowserRouter>
  </React.StrictMode>
);