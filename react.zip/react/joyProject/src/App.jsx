import React, { useState, useRef } from 'react';
import { CSSTransition } from 'react-transition-group';
import { FaIcon } from 'react-icons/fa';
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Sidebar from './Sidebar'; // Sidebar 컴포넌트 import
import Header from './Header';
import Router from "./router/root";


function App() {
  const [showSidebar, setShowSidebar] = useState(false);
  const sidebarRef = useRef(null);

  const toggleSidebar = () => {
    setShowSidebar(!showSidebar);
  };

  const handleOutsideClick = (event) => {
    if (showSidebar && !sidebarRef.current.contains(event.target)) {
      setShowSidebar(false);
    }
  };

  return (
    <div>
      <Header /> {/* toggleSidebar 함수를 전달 */}
      <CSSTransition
        in={showSidebar}
        timeout={300}
        classNames="sidebar"
        unmountOnExit
        nodeRef={sidebarRef} // nodeRef를 추가하여 sidebarRef를 전달
      >
        <Sidebar sidebarRef={sidebarRef} />
      </CSSTransition>
      {showSidebar && <div className="sidebar-backdrop" onClick={handleOutsideClick}></div>}
      <root />

    </div>
  );
}

export default App;