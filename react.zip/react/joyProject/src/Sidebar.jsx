import React from 'react';
import { createPortal } from 'react-dom';
import { CSSTransition } from 'react-transition-group';
import './Sidebar.css'; // Sidebar 스타일 import

function Sidebar({ sidebarRef }) {
  return createPortal(
    <CSSTransition
      in={true} // 이 부분을 적절하게 수정하세요 (사이드바가 열린 상태에 따라 조절)
      timeout={300}
      classNames="sidebar"
      unmountOnExit
      nodeRef={sidebarRef} // Sidebar 컴포넌트의 DOM 요소에 sidebarRef를 전달
    >
      <div ref={sidebarRef} className="sidebar">
        {/* 사이드바 내용 */}
        <div className="sidebar-header">Sidebar Header</div>
      </div>
    </CSSTransition>,
    document.body
  );
}

export default Sidebar;