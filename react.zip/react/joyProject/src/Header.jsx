import React, { useState } from 'react';
import './css/Header.css'; // Header 스타일 import
import { FaSpotify } from "react-icons/fa6";

function Header({ toggleSidebar }) {
  // 사용자 로그인 상태를 추적하는 state 설정
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // 로그인 상태 변경 함수
  const toggleLogin = () => {
    setIsLoggedIn(!isLoggedIn);
  };

  return (
    <header id="header">
      <div className="toggle-sidebar-wrapper" onClick={toggleSidebar}>
        <FaSpotify className="toggle-sidebar-icon" size={32} />
      <span className="sidebar-text">DobbyMusic</span>
      <div className="header-container">
        <div className="header-buttons">
          {/* 로그인 버튼 또는 로그아웃 버튼 렌더링 */}
          <button className='loginHeader' onClick={toggleLogin}>
            {isLoggedIn ? '로그아웃' : '로그인'}
          </button>
          {/* 가입하기 버튼 또는 마이페이지 버튼 렌더링 */}
          <button className='joinHeader'>
            {isLoggedIn ? '마이페이지' : '가입하기'}
          </button>
        </div>
      </div>
      </div>
    </header>
  );
}

export default Header;