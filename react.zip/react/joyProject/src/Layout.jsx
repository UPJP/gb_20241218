import React from 'react';
import Header from './Header'; // Header 컴포넌트 import

function Layout({ children }) {
  return (
    <div className="layout-container">
      <Header />
      <main>{children}</main>
      {/* 이곳에 다른 페이지 내용이 올 것입니다. */}
    </div>
  );
}

export default Layout;