import React from 'react';

const MainContent = () => {
  return (
    <section>
      {/* 타이틀 */}
      <div>
        <div>
          <h2><a>인기아티스트</a></h2>
        </div>
        <a>모두보기</a>
      </div>

      {/* 아이템요소 */}
      <article>
        <div role='button'>
        </div>
        <div></div>
        <div>
          <div>
            <figure>
              <div>
                <img src='https://i.scdn.co/image/ab67616100005174859e4c14fa59296c8649e0e4' />
                <div>
                  <button>
                    <span> play </span>
                    <svg> 아이콘 </svg>
                  </button>
                </div>
              </div>
              <div>
                <h4>//타이틀</h4>
                <p>작곡가</p>
              </div>
            </figure>
          </div>
        </div>
      </article>
      {/* 아이템요소 끝*/}
    </section>
  );
};

export default MainContent;